#include <stdint.h>

// --- Hardware Addresses ---
#define UART_DATA    (*(volatile uint8_t*) 0x20000000)
#define FPSQRT_REG   (*(volatile uint32_t*)0x40000000)
#define CRC_DATA     (*(volatile uint32_t*)0x60000000) 
#define CRC_POLY     (*(volatile uint32_t*)0x60000004) 

// Auto-run Benchmark -> Quit
const char sim_input[] = "5\nq"; 
int sim_idx = 1; 

// --- IO ---
void putchar(char c) { UART_DATA = c; }
void print(const char *p) { while (*p) putchar(*p++); }
char getchar() {
    if (sim_idx >= sizeof(sim_input)) return 0;
    char c = sim_input[sim_idx];
    if (c != '\0') { sim_idx++; for(volatile int k=0; k<50; k++); }
    return c;
}
void print_dec(uint32_t val) {
    if (val == 0) { putchar('0'); return; }
    char buffer[10]; int i = 0;
    while (val > 0) { buffer[i++] = (val % 10) + '0'; val /= 10; }
    while (--i >= 0) putchar(buffer[i]);
}

// --- CYCLE TIMER ---
uint32_t get_cycles() {
    uint32_t cycles;
    asm volatile ("rdcycle %0" : "=r"(cycles));
    return cycles;
}

// --- SOFTWARE REFERENCE ALGORITHMS ---
// Software Square Root (Binary Search)
uint32_t sw_sqrt(uint32_t n) {
    if (n < 2) return n;
    uint32_t low = 1, high = n, ans = 0;
    while (low <= high) {
        uint32_t mid = low + (high - low) / 2;
        if (mid <= n / mid) { ans = mid; low = mid + 1; } 
        else { high = mid - 1; }
    }
    return ans;
}

// Software CRC-32 (Bitwise)
uint32_t sw_crc32(uint32_t data, uint32_t poly) {
    uint32_t crc = 0xFFFFFFFF ^ data;
    for (int i = 0; i < 32; i++) {
        if (crc & 1) crc = (crc >> 1) ^ poly;
        else         crc = (crc >> 1);
    }
    return ~crc;
}

// --- BENCHMARK ---
void run_benchmark() {
    print("\f\n--- FINAL PERFORMANCE AUDIT ---\n");
    uint32_t start, end, hw_time, sw_time;

    // --- TEST 1: FPSQRT ---
    uint32_t test_num = 123456;
    print("[1] Square Root (Input: "); print_dec(test_num); print(")\n");
    
    // HW
    start = get_cycles();
    FPSQRT_REG = test_num;      
    uint32_t hw_res = FPSQRT_REG; 
    end = get_cycles();
    hw_time = end - start;
    
    // SW
    start = get_cycles();
    uint32_t sw_res = sw_sqrt(test_num);
    end = get_cycles();
    sw_time = end - start;

    // CHECK
    if (hw_res == sw_res) print("    STATUS: ACCURACY VERIFIED (MATCH)\n");
    else print("    STATUS: FAILURE (MISMATCH)\n");

    print("    HW Cycles: "); print_dec(hw_time); print("\n");
    print("    SW Cycles: "); print_dec(sw_time); print("\n");
    print("    Speedup: "); print_dec(sw_time / hw_time); print("x FASTER\n");

    // --- TEST 2: CRC-32 ---
    print("\n[2] CRC-32 (Input: 0xDEADBEEF)\n");
    CRC_POLY = 0xEDB88320; 

    // HW
    start = get_cycles();
    CRC_DATA = 0xDEADBEEF;   
    hw_res = CRC_DATA;       
    end = get_cycles();
    hw_time = end - start;

    // SW
    start = get_cycles();
    sw_res = sw_crc32(0xDEADBEEF, 0xEDB88320);
    end = get_cycles();
    sw_time = end - start;

    if (hw_res == sw_res) print("    STATUS: ACCURACY VERIFIED (MATCH)\n");
    else print("    STATUS: FAILURE (MISMATCH)\n");

    print("    HW Cycles: "); print_dec(hw_time); print("\n");
    print("    SW Cycles: "); print_dec(sw_time); print("\n");
    print("    Speedup: "); print_dec(sw_time / hw_time); print("x FASTER\n");
}

// --- Main ---
void main() {
    sim_idx = 0; 
    while(1) {
        print("\nMENU:\n [5] Run Audit\n [q] Quit\n> ");
        char choice = getchar();
        if (choice == 0) break;
        if (choice == '\n' || choice == '\r') continue;
        putchar(choice); print("\n");

        if (choice == '5') run_benchmark();
        else if (choice == 'q') break;
    }
    print("Done.\n");
    while(1);
}
